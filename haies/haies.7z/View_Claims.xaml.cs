﻿using Source;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace haies
{
    /// <summary>
    /// Interaction logic for View_Claims.xaml
    /// </summary>
    public partial class View_Claims : Window
    {
        Claim Claim;
        public View_Claims(Claim claim)
        {
            InitializeComponent();
            Claim = claim;
            Get_Claim();
        }
        private decimal Get_Balance(DateTime DateTime)
        {
            decimal Balance = 0;
            try
            {

                DB db = new DB();
                db.AddCondition("cstl_date", DateTime.Date, false, "<", "Date");
                db.AddCondition("cstl_cust_id", Claim.Id, false, "=", "cst_id");
                if (Claim.Type == Customer_type.مصنع)
                {
                    decimal.TryParse(db.Select(@"select COALESCE(sum(cstl_value),0) -(select COALESCE(sum((rec_sell_price*rec_amount)+(COALESCE(trs_sell_price,0)*COALESCE(rec_amount,1))
                                                    -trs_discount),0)- COALESCE(sum(trs_paid),0) from transportation left join receipt on rec_id= trs_rec_id where trs_date<@Date and trs_cust_id=@cst_id)
                                                     from customer_loans where cstl_date<@Date and cstl_cust_id=@cst_id; ").ToString(), out Balance);
                }
                else
                {
                    decimal.TryParse(db.Select(@"select COALESCE(sum(cstl_value),0) -(select COALESCE(sum(sin_cost),0) from station_income 
                                                 where sin_date<@Date and sin_cust_id=@cst_id)
                                                 from customer_loans where cstl_date<@Date and cstl_cust_id=@cst_id; ").ToString(), out Balance);

                }
            }
            catch
            {

            }
            return Balance * -1;
        }

        private void Get_Claim()
        {

            DB db = new DB();
            DataSet ds = new DataSet();
            decimal[] Totals = new decimal[] { 0, 0, 0, 0, 0 };
            try
            {
                db.AddCondition("trs_date", Claim.From, false, ">=", "SD");
                db.AddCondition("trs_date", Claim.To, false, "<=", "ED");
                db.AddCondition("cust_id", Claim.Id);
                if (Claim.Type == Customer_type.مصنع)
                {
                    ds = db.SelectSet(@"select rec_id,rec_number,trs_date,COALESCE(rec_amount,0) rec_amount,trs_paid,trs_discount,c.cem_name,unit_name,pl.pl_name,
                                                p.per_name customer,p2.per_name driver,cs.car_number, trs_payment_method,trs_card_number,
                                                COALESCE(rec_sell_price,0)+COALESCE(trs_sell_price,0)-(trs_discount/COALESCE(rec_amount,1)) unit_price,
                                                Round(COALESCE(rec_sell_price*rec_amount,0)+(COALESCE(trs_sell_price,0)*COALESCE(rec_amount,1))-trs_discount,2) total_price,                                     
                                                Round(COALESCE(rec_sell_price*rec_amount,0)+(COALESCE(trs_sell_price,0)*COALESCE(rec_amount,1))-trs_paid,2) trs_rest 
                                                from transportation t                                                                                            										      
                                                join drivers d on d.dri_id=trs_dri_id
                                                join cars cs on trs_car_id=car_id 
                                                join persons p2 on p2.per_id=d.dri_per_id                                         
                                                left join customer cu on cust_id = trs_cust_id 
                                                left join persons p on p.per_id = cust_per_id                                            
                                                left join places pl on pl.pl_id=t.trs_pl_id              
                                                left join  receipt r on t.trs_rec_id=r.rec_id  
                                                left join cement c on cem_id=rec_cem_id 
                                                left join units on rec_unit_id = unit_id                                
                                                where trs_date>=@SD and trs_date<=@ED and trs_cust_id=@cust_id order by trs_date,rec_number;
                                                select * from customer_loans where cstl_date>=@SD and cstl_date<=@ED and cstl_cust_id=@cust_id");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        Totals[1] += decimal.Parse(row["total_price"].ToString());
                        if (decimal.Parse(row["trs_paid"].ToString()) > 0)
                        {
                            ds.Tables[1].Rows.Add(null, null, row["trs_date"], row["trs_paid"], row["trs_payment_method"]);
                        }
                    }
                }
                else
                {
                    ds = db.SelectSet(@"select s.*,gas_name from station_income s join gas on gas_id=sin_gas_id where sin_date>=@SD and sin_date<=@ED and sin_cust_id=@cust_id order by sin_date;
                                        select * from customer_loans where cstl_date>=@SD and cstl_date<=@ED and cstl_cust_id=@cust_id order by cstl_date");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        Totals[1] += decimal.Parse(row["sin_cost"].ToString());
                    }

                }
                foreach (DataRow row in ds.Tables[1].Rows)
                {
                    Totals[2] += decimal.Parse(row["cstl_value"].ToString());
                }
                if (Claim.Type == Customer_type.مصنع)
                {
                    Customers_Out_DG.ItemsSource = ds.Tables[0].DefaultView;
                }
                else
                {
                    Customer_Out_DG.ItemsSource = ds.Tables[0].DefaultView;
                }
                ds.Tables[1].DefaultView.Sort = "cstl_date";
                Customers_In_DG.ItemsSource = ds.Tables[1].DefaultView;
                Totals[0] = Get_Balance(Claim.From);
                Totals[3] = Totals[1] - Totals[2];
                Totals[4] = Totals[3] + Totals[0];
                Balance_Before_TB.Text = Totals[0].ToString("0.00");
                Total_TB.Text = Totals[1].ToString("0.00");
                Paid_TB.Text = Totals[2].ToString("0.00");
                Rest_TB.Text = Totals[3].ToString("0.00");
                Balance_After_TB.Text = Totals[4].ToString("0.00");
            }
            catch
            {

            }
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {

        }

    }
}
