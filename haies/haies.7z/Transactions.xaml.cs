﻿using System;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Source;

namespace haies
{
    /// <summary>
    /// Interaction logic for daily_report.xaml
    /// </summary>
    public partial class Transactions : Page
    {
        int Dir;
        public Transactions(int dir)
        {
            InitializeComponent();
            Dir = dir;
            Get_Transactions();
        }

        private void Get_Transactions()
        {
            try
            {
                DB db = new DB();
                db.AddCondition("trc_date", From_DTP.Value.Value.Date, false, ">=", "SD");
                db.AddCondition("trc_date", To_DTP.Value.Value.Date, false, "<=", "ED");
                var dt = db.SelectTable(@"select * from transactions  
                                            where trc_date>=@SD and trc_date<=@ED ");
                if (dt.Rows.Count > 0)
                    dt.Rows.Add(null, null, To_DTP.Value.Value.Date, dt.Compute("Sum(trc_value)", ""), "الإجمالي", null, null);

               
                Transactions_DG.ItemsSource = dt.DefaultView;

            }
            catch
            {

            }
        }


        private void EP_Add(object sender, EventArgs e)
        {
            try
            {
                Add_Transactions F = new Add_Transactions(Dir);
                F.ShowDialog();
                Get_Transactions();
            }
            catch
            {

            }
        }

        private void EP_Edit(object sender, EventArgs e)
        {
            try
            {
                Add_Transactions F = new Add_Transactions(Dir, ((DataRowView)Transactions_DG.SelectedItem)["trc_id"]);
                F.ShowDialog();
                Get_Transactions();
            }
            catch
            {

            }
        }

        private void EP_Delete(object sender, EventArgs e)
        {
            try
            {
                if (Message.Show("هل تريد حذف هذا الحساب", MessageBoxButton.YesNoCancel, 5) == MessageBoxResult.Yes)
                {
                    DB db = new DB("transactions");
                    db.AddCondition("trc_id", ((DataRowView)Transactions_DG.SelectedItem)["trc_id"]);
                    db.Delete();
                    Get_Transactions();
                }
            }
            catch
            {

            }
        }

        private void From_DTP_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            try
            {
                if (this.IsLoaded)
                    Get_Transactions();
            }
            catch
            {

            }
        }


    }
}
