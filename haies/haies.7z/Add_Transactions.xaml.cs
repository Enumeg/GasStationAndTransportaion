﻿using System;
using System.Data;
using System.Windows;
using Source;

namespace haies
{
    /// <summary>
    /// Interaction logic for Add_Transactions.xaml
    /// </summary>
    public partial class Add_Transactions : Window
    {
        object Transaction_Id;
        int Dir;
        public Add_Transactions(int dir, object transaction_Id = null)
        {
            InitializeComponent();
            Dir = dir;
            Transaction_Id = transaction_Id;
          
            if (transaction_Id != null)
            {
                Get_Transaction_Info();
            }
        }

        private void Get_Transaction_Info()
        {
            try
            {
                DB db2 = new DB("transactions");

                db2.SelectedColumns.Add("*");

                db2.AddCondition("trc_id", Transaction_Id);

                DataRow DR = db2.SelectRow();
                //...Set Data into controls...\\
                Date_DTP.Value = DateTime.Parse(DR["trc_date"].ToString());
                Value_TB.Text = DR["trc_value"].ToString();
                Description_TB.Text = DR["trc_description"].ToString();
                Number_TB.Text = DR["trc_number"].ToString();
                From_TB.Text = DR["trc_from"].ToString();
                To_TB.Text = DR["trc_to"].ToString();
                

            }
            catch
            {


            }
        }

        private bool Add_Update()
        {
            try
            {
                //create new DB giving table name
                DB DataBase = new DB("transactions");
                //add columns names and inserted or update values
                DataBase.AddColumn("trc_number", Number_TB.Text);
                DataBase.AddColumn("trc_date", Date_DTP.Value.Value.Date);
                DataBase.AddColumn("trc_value", Value_TB.Text);
                DataBase.AddColumn("trc_description", Description_TB.Text);
                DataBase.AddColumn("trc_from", From_TB.Text);
                DataBase.AddColumn("trc_to", To_TB.Text);
                //check if id is null if null insert else update
                if (Transaction_Id == null)
                {
                    DataBase.AddColumn("trc_direction", Dir);
                    DataBase.AddColumn("trc_user_id", 6);//App.User_Id
                    //check if this item has inserted before 
                    if (DataBase.IsNotExist("trc_id", "trc_direction", "trc_number"))
                    {
                        //insert row
                        return DataBase.Insert();
                    }
                    else
                    {
                        Message.Show("هذا المستند موجود من قبل", MessageBoxButton.OK, 5);
                        return false;
                    }
                }
                else
                {
                    // update row giving the id
                    DataBase.AddCondition("trc_id", Transaction_Id);
                    return DataBase.Update();
                }
            }
            catch
            {
                return false;
            }
        }

        private void Add_Update_Transaction_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Check for required inputs
              
                //try to add or update return true if ok
                if (Confirm.Check(Add_Update()))
                {
                    //check New checkBox status
                    if ((bool)New.IsChecked)
                    {
                       
                    }
                    else
                    {
                        //close window
                        this.Close();
                    }
                }
            }
            catch
            {

            }
        }

    }
}
